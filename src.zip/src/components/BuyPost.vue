a<template>
  <div class="container-fluid mt-4">
    <h1 class="h1">Purchasing product {{ postID }}</h1>
    <b-alert :show="loading" variant="info">Loading...</b-alert>
  </div>
</template>

<script>
import api from '@/api'
export default {
  // props: ['buyObject'],
  data () {
    return {
      activeUser: null,
      loading: false,
      posts: [],
      email: '',
      postID: '',
      postDetails: {}
    }
  },
  async created () {
    this.activeUser = await this.$auth.getUser()
    this.email = this.activeUser.preferred_username
    this.postID = this.$route.query.postID
    if (this.postID === undefined) {
      this.$router.push('/posts-manager')
    }
    try {
      this.postDetails = await api.getPost(this.postID)
    } catch (e) {
      alert('This listing was not found. It might have been taken down or not available at this time')
      this.$router.push('/posts-manager')
    }
  },
  methods: {
    async getPost (postID) {
      this.loading = true
      this.posts = await api.getPosts()
      this.loading = false
    },
    async populatePostToBuy (post) {
      this.buyObject = Object.assign({}, post)
      this.$router.push('/buy-post')
    }
  }
}
</script>