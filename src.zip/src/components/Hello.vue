<template>
  <b-jumbotron>
    <template slot="header">
      Peddle
    </template>
    <template slot="lead">
      Welcome to Peddle. You're primary marketplace for tech products.
    </template>
    <hr class="my-4">
    <p>
      Use the buttons below to explore more... 
    </p>
    <b-btn variant="primary" size="lg" href="/posts-manager">Check New Listings</b-btn>
    <b-btn variant="primary" size="lg" href="/my-profile">View Your Profile</b-btn>
  </b-jumbotron>
</template>

<style>
</style>