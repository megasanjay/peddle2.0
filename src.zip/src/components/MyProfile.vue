<template>
  <div class="container-fluid mt-4">
    <h1 class="h1">My Posts</h1>
    <b-alert :show="loading" variant="info">Loading...</b-alert>
    <b-row>
      <b-col>
        <table class="table table-striped">
          <thead>
            <tr>
              <th>ID</th>
              <th>Title</th>
              <th>Description</th>
              <th>Product ID</th>
              <th>Created</th>
              <th>Updated</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="post in tempPosts" :key="post.postID">
              <td>{{ post.postID }}</td>
              <td>{{ post.title }}</td>
              <td>{{ post.description }}</td>
              <td>{{ post.productID }}</td>
              <td>{{ post.createdAt }}</td>
              <td>{{ post.updatedAt }}</td>
              <td class="text-right">
                <a href="#" @click.prevent="populatePostToEdit(post)"  v-on:click="isHidden = false">Edit</a> -
                <a href="#" @click.prevent="deletePost(post.postID)">Delete</a>
              </td>
            </tr>
          </tbody>
        </table>
      </b-col>
      <b-col lg="3" v-if="!isHidden">
        <b-card :title="(model.id ? 'Edit Post ID: ' + model.postID : 'New Post')">
          <form @submit.prevent="savePost">
            <b-form-group label="Title">
              <b-form-input type="text" v-model="model.title"></b-form-input>
            </b-form-group>
            <b-form-group label="Description">
              <b-form-textarea rows="4" v-model="model.description"></b-form-textarea>
            </b-form-group>
            <div>
              <b-btn type="submit" variant="success">Save Post</b-btn>
            </div>
          </form>
        </b-card>
      </b-col>
    </b-row>
  </div>
</template>

<script>
import api from '@/api'
export default {
  props: {
    // email: String
  },
  data () {
    return {
      loading: false,
      posts: [],
      model: {},
      email: null,
      tempPosts: [],
      isHidden: true
    }
  },
  async created () {
    this.email = this.$parent.email
    this.refreshPosts()
  },
  methods: {
    async refreshPosts () {
      this.tempPosts = []
      this.loading = true
      this.posts = await api.getPosts()
      for (let post in this.posts) {
        if (this.posts[post].email === this.email) {
          this.tempPosts.push(this.posts[post])
        }
      }
      this.loading = false
    },
    async populatePostToEdit (post) {
      this.model = Object.assign({}, post)
    },
    async savePost () {
      if (this.model.postID) {
        await api.updatePost(this.model.postID, this.model)
      } else {
        // await api.createPost(this.model)
      }
      this.model = {} // reset form
      this.isHidden = true
      await this.refreshPosts()
    },
    async deletePost (postID) {
      if (confirm('Are you sure you want to delete this post?')) {
        // if we are editing a post we deleted, remove it from the form
        if (this.model.postID === postID) {
          this.model = {}
        }
        await api.deletePost(postID)
        await this.refreshPosts()
      }
    }
  }
}
</script>